package com.example.tr.instantcool2.LocalDB;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by TR on 2017/10/11.
 */

public class UserInfoSotrage {

    public static String Name;

    public static  String Account;

    public static  String pwd;

    public static List<String> inviters = new ArrayList<String>();

}
