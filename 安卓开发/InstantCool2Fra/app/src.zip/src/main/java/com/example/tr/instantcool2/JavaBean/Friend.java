package com.example.tr.instantcool2.JavaBean;

/**
 * Created by tangz on 2017/10/23.
 */

public class Friend {
    String FriendName;
    String FriendAccount;


    public String getFriendName() {
        return FriendName;
    }

    public void setFriendName(String friendName) {
        FriendName = friendName;
    }

    public String getFriendAccount() {
        return FriendAccount;
    }

    public void setFriendAccount(String friendAccount) {
        FriendAccount = friendAccount;
    }
}
