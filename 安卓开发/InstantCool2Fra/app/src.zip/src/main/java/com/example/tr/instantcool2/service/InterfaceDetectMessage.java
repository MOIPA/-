package com.example.tr.instantcool2.service;

/**
 * Created by TR on 2017/10/18.
 */

public interface InterfaceDetectMessage {

    public int GetMessageCount();

}
